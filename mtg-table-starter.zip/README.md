# MTG Table — prototipo inicial

Aplicación web para crear mesas de Magic, unirse con un código y llevar vidas/veneno/turnos.

## Estado de este prototipo

- La pantalla inicial y el contador funcionan en modo demostración local.
- Para conectar distintos teléfonos hay que configurar Supabase.
- Esta es una base de desarrollo, no una versión lista para producción ni para torneos oficiales.
- El prototipo aún no implementa QR real, daño de comandante, historial persistente, sistema de cronometraje por jugador ni validación robusta de cupos.

## 1. Requisitos

Instala Node.js 20.9 o superior y Git.

## 2. Ejecutar en tu computador

```bash
npm install
npm run dev
```

Abre la dirección local que muestra Vite.

## 3. Crear Supabase

1. Crea un proyecto en https://supabase.com/
2. En Authentication > Providers, habilita Anonymous Sign-Ins.
3. Abre SQL Editor y ejecuta `supabase/schema.sql`.
4. En Project Settings > API, copia Project URL y la clave `anon`/publishable.
5. Copia `.env.example` a `.env.local` y completa las dos variables.

Ejemplo:

```env
VITE_SUPABASE_URL=https://abcxyz.supabase.co
VITE_SUPABASE_ANON_KEY=tu-clave-publica
```

Reinicia `npm run dev` después de modificar `.env.local`.

## 4. Publicar

Puedes subir el repositorio a GitHub y desplegarlo como sitio estático en Cloudflare Pages:
- Framework preset: Vite
- Build command: `npm run build`
- Build output directory: `dist`
- Variables de entorno: `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY`

No publiques nunca una clave `service_role` en el navegador.

## 5. Antes de abrirlo al público

Este esquema es un punto de partida para pruebas. Antes de producción hay que reforzar la seguridad y validar:
- quién puede unirse y ocupar cada asiento;
- quién puede cambiar turnos o cerrar una sala;
- límites de frecuencia y protección contra abuso;
- caducidad y limpieza de salas;
- protección contra dos acciones simultáneas;
- validación de datos en servidor;
- pruebas de desconexión y reconexión.

La clave anon/publicable está diseñada para estar en el cliente cuando RLS está bien configurado. Nunca compartas contraseñas ni claves secretas.
