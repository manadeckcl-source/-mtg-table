import { useEffect, useMemo, useState } from "react";
import { Activity, Copy, Crown, Heart, Minus, Plus, QrCode, RefreshCw, Shield, Swords, Timer, Users, Wifi, WifiOff } from "lucide-react";
import { ensureGuestSession, isConfigured, supabase } from "./supabase";

type Player = {
  id: string; room_code: string; display_name: string; seat: number;
  life_total: number; poison: number; is_alive: boolean;
};
type Room = { code: string; format: string; starting_life: number; turn_seat: number; status: string };

const randomCode = () => Math.random().toString(36).slice(2, 6).toUpperCase();
const palettes = ["green", "blue", "red", "purple", "gold", "teal"];

export default function App() {
  const [room, setRoom] = useState<Room | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [format, setFormat] = useState("Commander");
  const [startingLife, setStartingLife] = useState(40);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [demo, setDemo] = useState(!isConfigured);

  const sortedPlayers = useMemo(() => [...players].sort((a,b) => a.seat-b.seat), [players]);

  useEffect(() => {
    if (!room || demo || !supabase) return;
    const channel = supabase.channel(`room-${room.code}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "mtg_players", filter: `room_code=eq.${room.code}` }, () => loadPlayers(room.code))
      .on("postgres_changes", { event: "*", schema: "public", table: "mtg_rooms", filter: `code=eq.${room.code}` }, () => loadRoom(room.code))
      .subscribe();
    loadPlayers(room.code);
    return () => { supabase.removeChannel(channel); };
  }, [room?.code, demo]);

  useEffect(() => {
    if (!startedAt) return;
    const id = window.setInterval(() => setElapsed(Math.floor((Date.now()-startedAt)/1000)), 1000);
    return () => window.clearInterval(id);
  }, [startedAt]);

  async function loadPlayers(roomCode: string) {
    if (!supabase) return;
    const { data, error } = await supabase.from("mtg_players").select("*").eq("room_code", roomCode).order("seat");
    if (!error && data) setPlayers(data as Player[]);
  }
  async function loadRoom(roomCode: string) {
    if (!supabase) return;
    const { data } = await supabase.from("mtg_rooms").select("*").eq("code", roomCode).single();
    if (data) setRoom(data as Room);
  }
  function makeDemoRoom() {
    const c = randomCode();
    const fake: Player[] = [
      {id:"demo1",room_code:c,display_name:name.trim() || "Tú",seat:0,life_total:startingLife,poison:0,is_alive:true},
      {id:"demo2",room_code:c,display_name:"Jugador 2",seat:1,life_total:startingLife,poison:0,is_alive:true},
      {id:"demo3",room_code:c,display_name:"Jugador 3",seat:2,life_total:startingLife,poison:0,is_alive:true},
      {id:"demo4",room_code:c,display_name:"Jugador 4",seat:3,life_total:startingLife,poison:0,is_alive:true}
    ];
    setRoom({code:c,format,starting_life:startingLife,turn_seat:0,status:"active"});
    setPlayers(fake); setStartedAt(Date.now()); setElapsed(0); setDemo(true); setError("");
  }
  async function createRoom() {
    setBusy(true); setError("");
    try {
      if (!isConfigured || !supabase) { makeDemoRoom(); return; }
      await ensureGuestSession();
      const c = randomCode();
      const { data: auth } = await supabase.auth.getUser();
      const { error: roomError } = await supabase.from("mtg_rooms").insert({code:c,format,starting_life:startingLife,turn_seat:0,status:"active",created_by:auth.user?.id});
      if (roomError) throw roomError;
      const { error: playerError } = await supabase.from("mtg_players").insert({room_code:c,display_name:name.trim() || "Jugador 1",seat:0,life_total:startingLife,poison:0,is_alive:true,owner_id:auth.user?.id});
      if (playerError) throw playerError;
      setRoom({code:c,format,starting_life:startingLife,turn_seat:0,status:"active"});
      setStartedAt(Date.now()); setElapsed(0);
    } catch (e:any) { setError(e.message || "No se pudo crear la sala."); }
    finally { setBusy(false); }
  }
  async function joinRoom() {
    setBusy(true); setError("");
    try {
      if (!isConfigured || !supabase) {
        setError("La demo local permite probar la interfaz, pero para unirse desde otro teléfono debes configurar Supabase.");
        return;
      }
      await ensureGuestSession();
      const c = code.trim().toUpperCase();
      const { data: r, error: re } = await supabase.from("mtg_rooms").select("*").eq("code",c).single();
      if (re || !r) throw new Error("No encontramos esa sala. Revisa el código.");
      const { data: existing } = await supabase.from("mtg_players").select("seat").eq("room_code",c);
      const seat = (existing?.length ?? 0);
      if (seat >= 6) throw new Error("La sala ya tiene 6 jugadores.");
      const { data: auth } = await supabase.auth.getUser();
      const { error: pe } = await supabase.from("mtg_players").insert({room_code:c,display_name:name.trim() || `Jugador ${seat+1}`,seat,life_total:r.starting_life,poison:0,is_alive:true,owner_id:auth.user?.id});
      if (pe) throw pe;
      setRoom(r as Room); setStartedAt(Date.now());
    } catch (e:any) { setError(e.message || "No se pudo entrar a la sala."); }
    finally { setBusy(false); }
  }
  async function changePlayer(p: Player, field: "life_total"|"poison", delta: number) {
    const next = Math.max(0, p[field] + delta);
    setPlayers(old => old.map(x => x.id===p.id ? {...x,[field]:next} : x));
    if (!demo && supabase) {
      const { error } = await supabase.from("mtg_players").update({[field]:next}).eq("id",p.id);
      if (error) setError(error.message);
    }
  }
  async function passTurn() {
    if (!room) return;
    const next = (room.turn_seat + 1) % Math.max(players.length,1);
    setRoom({...room,turn_seat:next});
    if (!demo && supabase) {
      const { error } = await supabase.from("mtg_rooms").update({turn_seat:next}).eq("code",room.code);
      if (error) setError(error.message);
    }
  }
  function leaveRoom() { setRoom(null); setPlayers([]); setStartedAt(null); setElapsed(0); setError(""); setNotice(""); }
  const time = `${String(Math.floor(elapsed/3600)).padStart(2,"0")}:${String(Math.floor(elapsed%3600/60)).padStart(2,"0")}:${String(elapsed%60).padStart(2,"0")}`;

  return <main className="app-shell">
    <header className="topbar">
      <a className="brand" href="#"><span className="brand-mark">✦</span><span>MTG <b>TABLE</b><small>PLAY TOGETHER</small></span></a>
      <span className={`connection ${demo ? "offline" : "online"}`}>{demo ? <WifiOff size={14}/> : <Wifi size={14}/>} {demo ? "Modo demostración" : "Conectado"}</span>
    </header>
    {!room ? <section className="hero">
      <div className="eyebrow"><span/> MAGIC: THE GATHERING · MULTIPLAYER</div>
      <h1>Tu mesa.<br/><em>Tus reglas.</em></h1>
      <p className="intro">Conecta a tus amigos, controla la partida y deja que el juego fluya. Sin descargar nada.</p>
      <div className="setup-card">
        <div className="field"><label>Tu nombre o apodo</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="Ej. Planeswalker123" maxLength={24}/></div>
        <div className="field-row">
          <div className="field"><label>Formato</label><select value={format} onChange={e=>setFormat(e.target.value)}><option>Commander</option><option>Casual</option><option>Two-Headed Giant</option><option>Personalizado</option></select></div>
          <div className="field"><label>Vidas iniciales</label><select value={startingLife} onChange={e=>setStartingLife(Number(e.target.value))}><option value={20}>20 vidas</option><option value={30}>30 vidas</option><option value={40}>40 vidas</option></select></div>
        </div>
        <button className="primary-button" onClick={createRoom} disabled={busy}><Users size={18}/> {busy ? "Creando..." : "Crear una mesa"}</button>
        <div className="or"><span/> o únete a una mesa <span/></div>
        <div className="join-row"><input value={code} onChange={e=>setCode(e.target.value.toUpperCase())} placeholder="CÓDIGO DE SALA" maxLength={4}/><button className="secondary-button" onClick={joinRoom} disabled={busy || code.trim().length!==4}>Unirme</button></div>
        {!isConfigured && <p className="demo-note"><Activity size={14}/> Estás viendo una demo interactiva. Configura Supabase para conectar distintos teléfonos.</p>}
      </div>
      {error && <p className="error">{error}</p>}
      <div className="feature-strip"><span><Shield size={15}/> Sin registro obligatorio</span><span><QrCode size={15}/> Sala compartida</span><span><Timer size={15}/> Tiempo de partida</span></div>
    </section> : <section className="table-view">
      <div className="table-heading">
        <div><div className="eyebrow">MESA ACTIVA · {room.format.toUpperCase()}</div><h2>La partida está en marcha</h2><p className="muted">Comparte el código para que se unan tus amigos.</p></div>
        <button className="icon-button" title="Salir de la sala" onClick={leaveRoom}>Salir</button>
      </div>
      <div className="room-banner"><div><small>CÓDIGO DE SALA</small><strong>{room.code}</strong></div><button onClick={()=>{navigator.clipboard?.writeText(room.code);setNotice("Código copiado.");}}><Copy size={16}/> Copiar</button></div>
      {notice && <p className="notice">{notice}</p>}
      <div className="table-meta"><span><Timer size={16}/> {time}</span><span><Users size={16}/> {players.length} jugadores</span><span><Crown size={16}/> Turno de {sortedPlayers.find(p=>p.seat===room.turn_seat)?.display_name || "—"}</span></div>
      <div className="player-grid">{sortedPlayers.map((p,i)=><article className={`player-card ${palettes[i%palettes.length]} ${p.seat===room.turn_seat ? "active-turn":""}`} key={p.id}>
        <div className="player-top"><span className="seat">JUGADOR {p.seat+1}</span>{p.seat===room.turn_seat && <span className="turn-tag">TURNO</span>}</div>
        <h3>{p.display_name}</h3>
        <div className="life-label"><Heart size={15}/> VIDAS</div>
        <div className="life-value">{p.life_total}</div>
        <div className="counter-controls"><button aria-label="Restar vida" onClick={()=>changePlayer(p,"life_total",-1)}><Minus/></button><button aria-label="Sumar vida" onClick={()=>changePlayer(p,"life_total",1)}><Plus/></button></div>
        <div className="poison-row"><span>☠ Veneno</span><div><button onClick={()=>changePlayer(p,"poison",-1)}><Minus size={13}/></button><b>{p.poison}</b><button onClick={()=>changePlayer(p,"poison",1)}><Plus size={13}/></button></div></div>
      </article>)}</div>
      <div className="turn-actions"><button className="primary-button" onClick={passTurn}>Pasar turno <Swords size={17}/></button><button className="secondary-button" onClick={()=>!demo && room && loadPlayers(room.code)}><RefreshCw size={16}/> Actualizar</button></div>
      <p className="demo-note">{demo ? "Demo: los cambios solo viven en este navegador; no se comparten con otros teléfonos todavía." : "Los cambios se sincronizan mediante Supabase Realtime. Versión inicial de pruebas."}</p>
    </section>}
    <footer>MTG TABLE <span>·</span> UNOFFICIAL COMMUNITY PROJECT <span>·</span> NOT AFFILIATED WITH WIZARDS OF THE COAST</footer>
  </main>;
}
