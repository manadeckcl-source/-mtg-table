import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const isConfigured = Boolean(url && key);
export const supabase = isConfigured ? createClient(url!, key!) : null;

export async function ensureGuestSession() {
  if (!supabase) throw new Error("Falta configurar Supabase. Revisa el archivo .env.local.");
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    const { error } = await supabase.auth.signInAnonymously();
    if (error) throw error;
  }
}
