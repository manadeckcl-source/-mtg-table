-- MTG Table: esquema inicial para pruebas.
-- Ejecuta este archivo en Supabase > SQL Editor.
-- Requiere habilitar Anonymous Sign-Ins en Authentication > Providers.

create table if not exists public.mtg_rooms (
  code text primary key,
  format text not null default 'Commander',
  starting_life integer not null default 40,
  turn_seat integer not null default 0,
  status text not null default 'active',
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.mtg_players (
  id uuid primary key default gen_random_uuid(),
  room_code text not null references public.mtg_rooms(code) on delete cascade,
  display_name text not null,
  seat integer not null,
  life_total integer not null default 40,
  poison integer not null default 0,
  is_alive boolean not null default true,
  owner_id uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  unique(room_code, seat)
);

alter table public.mtg_rooms enable row level security;
alter table public.mtg_players enable row level security;

-- Salas: cualquier usuario autenticado anónimamente puede consultar.
create policy "authenticated can read rooms"
on public.mtg_rooms for select to authenticated using (true);

create policy "authenticated can create own rooms"
on public.mtg_rooms for insert to authenticated
with check (created_by = auth.uid());

create policy "room members can update turn"
on public.mtg_rooms for update to authenticated
using (
  exists(select 1 from public.mtg_players p
         where p.room_code = mtg_rooms.code and p.owner_id = auth.uid())
)
with check (true);

-- Jugadores: todos los miembros autenticados pueden ver el estado de la mesa.
create policy "authenticated can read players"
on public.mtg_players for select to authenticated using (true);

create policy "users can add themselves"
on public.mtg_players for insert to authenticated
with check (owner_id = auth.uid());

create policy "users can update their own player"
on public.mtg_players for update to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

-- Realtime: publicar cambios de estas tablas.
alter publication supabase_realtime add table public.mtg_rooms;
alter publication supabase_realtime add table public.mtg_players;
